/***************************/
/* maintypes.h             */
/***************************/

struct bind {
	char marker;	/* detect the kind of element */
	unsigned long time;
	struct bind *next;
	void *data;
};

struct KeySig {          /* marker == 'k' */
	short sign;
};

struct Lyric {           /* marker == 'l' */
	char *text;
};

struct TimeSig {         /* marker == 't' */
	short nom, denom;
};

struct Note {            /* marker == 'n' */
	short octave, pitch, loud;
	unsigned long end;
	int duration;
	short flags;
	int beam_nr, slur_nr;
	char note_pos, slur_pos, beam_pos;
	char treated;
	char next_beamn_kind;
	struct Note *accord_next;
};

struct Rest {            /* marker == 'r' */
	char position;
	int kind;
	char flg;		/* indicates a useful skip */
};

struct Loudness {        /* marker == 'p' */
	int statics, dynamics;
};

