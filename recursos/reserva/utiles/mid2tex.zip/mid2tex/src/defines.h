/***************************/
/* defines.h               */
/***************************/

#define MAXTRACKS 30     /* maximum for number of tracks */
/* #define DEBUG 0 */
