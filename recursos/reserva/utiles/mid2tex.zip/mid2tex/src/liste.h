/***************************/
/* liste.h                 */
/***************************/

static struct element {
	int oct, pit, laut, chann;
	unsigned long int t;
	struct element *folger;
} *anker;

