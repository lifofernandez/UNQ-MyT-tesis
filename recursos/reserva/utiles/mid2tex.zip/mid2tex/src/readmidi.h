/***************************/
/* readmidi.h              */
/***************************/

FILE *fp, *tfp;
static Header head;
static Track_Header THead;

#ifdef DEBUG
static double D_Tempo;
extern void debug_out();
#endif

static double one64tel, sequencecounter, lastsc;
static unsigned long converter, bartime, lastbartime;

static char Running_Event;
static char notes_flag;
static unsigned long zeit;
static int help;
static int taktzeit;
static unsigned long diskrete_tz;
static unsigned long int firstnotetime;
static int firstnotetimeflag;
static int Signature;
static int T_genus;
static int Track_Nr;
static char printonly;                  /* for one track processing */
char Staffs[MAXTRACKS][100];            /* names of instruments */
char TrackName[MAXTRACKS][80];          /* names of tracks */
char texfilename[50];			/* name of texfile */
static unsigned char max[MAXTRACKS];
static unsigned char min[MAXTRACKS];

char region[MAXTRACKS];                 /* 0 both, 1 violine, 2 bass */
static char count;                      /* count_only bit */
static short nom0, denom0, key0;        /* for first track datas */

static int valid, valid2;

static int ReadEvent();

extern void ins_dyn_event();
extern void note_insert();
extern int note_delete();
extern int search_note();
extern void dyn_init();
extern void split_notes();
extern void detect_accords();
extern void insert_notetimes_and_slurs();
extern void detect_note_positions_with_signs();
extern void set_slur_regions();
extern void reset_treat_info();
extern void beam_detect();
extern void set_beam_regions();
extern void slur_geometry();
extern void detect_rests();
extern void beam_geometry();
extern void calculate_rest_positions();
extern void set_loudness_infos();
extern void write_texfile();
